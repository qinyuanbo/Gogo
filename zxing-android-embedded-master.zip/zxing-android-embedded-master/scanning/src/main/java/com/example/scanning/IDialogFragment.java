package com.example.scanning;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.TextView;

import androidx.fragment.app.DialogFragment;

public class IDialogFragment extends DialogFragment {
    String lal;
    String lal2;

    public IDialogFragment(String lal, String lal2) {
        this.lal = lal;
        this.lal2 = lal2;
    }

    @Override
    public Dialog onCreateDialog(Bundle savedInstanceState) {
        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
        LayoutInflater inflater = requireActivity().getLayoutInflater();
        View inflate = inflater.inflate(R.layout.ceshi_ceshi, null);
        TextView text = inflate.findViewById(R.id.button);
        TextView text2 = inflate.findViewById(R.id.button2);
        text.setText(lal);
        text2.setText(lal2);
        builder.setView(inflate)
                // Add action buttons
                .setPositiveButton("ceshi", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int id) {
                        // sign in the user ...
                    }
                })
                .setNegativeButton("ceshi", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {

                    }
                });

        // Inflate and set the layout for the dialog
        // Pass null as the parent view because its going in the dialog layout

        return builder.create();
    }

}
