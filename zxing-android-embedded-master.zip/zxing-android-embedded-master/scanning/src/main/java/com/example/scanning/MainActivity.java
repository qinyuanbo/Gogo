package com.example.scanning;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.KeyEvent;
import android.widget.TextView;

import com.google.zxing.integration.android.IntentIntegrator;
import com.google.zxing.integration.android.IntentResult;
import com.journeyapps.barcodescanner.CaptureManager;
import com.journeyapps.barcodescanner.DecoratedBarcodeView;

public class MainActivity extends AppCompatActivity {
    private CaptureManager capture;
    private DecoratedBarcodeView barcodeScannerView;
    TextView textView;
    IntentIntegrator intentIntegrator;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        barcodeScannerView = (DecoratedBarcodeView) findViewById(R.id.dbv_custom);
         textView= (TextView) findViewById(R.id.textview2);

        capture = new CaptureManager(this, barcodeScannerView);
        capture.initializeFromIntent(getIntent(), savedInstanceState);
        capture.setResultCallBack(new CaptureManager.ResultCallBack() {
            @Override
            public void callBack(int requestCode, int resultCode, Intent intent) {
                IntentResult result = IntentIntegrator.parseActivityResult(requestCode, resultCode, intent);
                if (null != result && null != result.getContents()) {
                    showDialog(result.getContents());
                    intentIntegrator.initiateScan();
                }
            }
        });
        capture.decode();
        intentIntegrator= new IntentIntegrator(this);
        intentIntegrator.setCaptureActivity(MainActivity.class);
        intentIntegrator.setDesiredBarcodeFormats(IntentIntegrator.ONE_D_CODE_TYPES);
        intentIntegrator.setPrompt("请对准二维码");
        intentIntegrator.setCameraId(0);
        intentIntegrator.setBeepEnabled(false);
        intentIntegrator.setBarcodeImageEnabled(false);
        intentIntegrator.initiateScan();// 扫码的类型,可选：一维码，二维码，一/二维码
// 设置提示语
// 选择摄像头,可使用前置或者后置
// 是否开启声音,扫完码之后会"哔"的一声
// 扫完码之后生成二维码的图片
// 初始化扫码
    }

    public void showDialog(String result) {
        new IDialogFragment(result,result).show(getSupportFragmentManager(),"ceshi");
        // 重新拉起扫描
        capture.onResume();
        capture.decode();
    }

    @Override
    protected void onResume() {
        super.onResume();
        capture.onResume();
        Log.d("ceshi","ceshi");
    }

    @Override
    protected void onPause() {
        super.onPause();
        capture.onResume();

    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        capture.onDestroy();
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        capture.onSaveInstanceState(outState);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String permissions[], @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        capture.onRequestPermissionsResult(requestCode, permissions, grantResults);
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        return barcodeScannerView.onKeyDown(keyCode, event) || super.onKeyDown(keyCode, event);
    }
}