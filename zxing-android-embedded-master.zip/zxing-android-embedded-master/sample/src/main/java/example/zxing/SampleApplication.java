package example.zxing;

import androidx.multidex.MultiDexApplication;

/**
 *
 */
public class SampleApplication extends MultiDexApplication {
    @Override
    public void onCreate() {
        super.onCreate();
    }
}
